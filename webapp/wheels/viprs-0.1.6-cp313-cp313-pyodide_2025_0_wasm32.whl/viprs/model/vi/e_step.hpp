#ifndef E_STEP_H
#define E_STEP_H

#include <cmath>
#include <algorithm>
#include <stdio.h>
#include <iostream>
#include <limits>
#include <type_traits>

#ifdef __wasm_simd128__
    #include <wasm_simd128.h>
#endif

// Check for and include `cblas`:
#ifdef HAVE_CBLAS
    #include <cblas.h>
#endif

// Check for and include `omp`:
#ifdef _OPENMP
    #include <omp.h>
#endif


/* ------------------------------------------------------------------------ */
// Helper system-related functions to check for BLAS and OpenMP support

bool omp_supported() {
    /* Check if OpenMP is supported by examining compiler flags. */
    #ifdef _OPENMP
        return true;
    #else
        return false;
    #endif
}

bool simd_supported() {
    /* WebAssembly SIMD is enabled independently of OpenMP threading. */
    #ifdef __wasm_simd128__
        return true;
    #else
        return false;
    #endif
}

bool blas_supported() {
    /* Check if BLAS is supported by examining compiler flags. */
    #ifdef HAVE_CBLAS
        return true;
    #else
        return false;
    #endif
}

/* ------------------------------------------------------------------------ */
// Linear algebra + math functions

template <typename T>
typename std::enable_if<std::is_floating_point<T>::value, T>::type
clamp(T x, T min, T max)
{
    /* Clamp a scalar value between a minimum `min` and maximum `max` value. */
    if (x < min) x = min;
    if (x > max) x = max;

    return x;
}

template <typename T>
typename std::enable_if<std::is_floating_point<T>::value, T>::type
c_max(T* x, int size) {
    /* Find the maximum value in a vector x of length `size`. */

    T current_max = x[0];

    for (int i = 1; i < size; ++i) {
        if (current_max < x[i]) {
            current_max = x[i];
        }
    }
    return current_max;
}

/* ------------------------------------------------------------------------ */
// Dot product functions

// Define a function pointer for the dot product functions `dot` and `blas_dot`:
template <typename T, typename U>
using dot_func_pt = typename std::enable_if<std::is_floating_point<T>::value && std::is_arithmetic<U>::value, T>::type (*)(T*, U*, int);

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

template <typename T, typename U>
typename std::enable_if<std::is_floating_point<T>::value && std::is_arithmetic<U>::value, T>::type
dot(T* x, U* y, int size) {
    /* Perform dot product between two vectors x and y, each of length `size`

    :param x: Pointer to the first element of the first vector
    :param y: Pointer to the first element of the second vector
    :param size: Length of the vectors

    */

    #ifdef __wasm_simd128__
        if constexpr (std::is_same<T, float>::value && std::is_same<U, float>::value) {
            v128_t sums = wasm_f32x4_splat(0.f);
            int i = 0;
            for (; i + 4 <= size; i += 4) {
                sums = wasm_f32x4_add(
                    sums,
                    wasm_f32x4_mul(wasm_v128_load(x + i), wasm_v128_load(y + i))
                );
            }
            alignas(16) float lanes[4];
            wasm_v128_store(lanes, sums);
            T result = lanes[0] + lanes[1] + lanes[2] + lanes[3];
            for (; i < size; ++i) result = std::fma(y[i], x[i], result);
            return result;
        } else if constexpr (std::is_same<T, double>::value && std::is_same<U, double>::value) {
            v128_t sums = wasm_f64x2_splat(0.);
            int i = 0;
            for (; i + 2 <= size; i += 2) {
                sums = wasm_f64x2_add(
                    sums,
                    wasm_f64x2_mul(wasm_v128_load(x + i), wasm_v128_load(y + i))
                );
            }
            alignas(16) double lanes[2];
            wasm_v128_store(lanes, sums);
            T result = lanes[0] + lanes[1];
            for (; i < size; ++i) result = std::fma(y[i], x[i], result);
            return result;
        }
    #endif

    T s = 0.;
    #ifdef _OPENMP
        #ifndef _WIN32
            #pragma omp simd
        #endif
    #endif
    for (int i = 0; i < size; ++i) {
        s = std::fma(static_cast<T>(y[i]), x[i], s);
    }
    return s;
}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

template <typename T, typename U>
typename std::enable_if<std::is_floating_point<T>::value && std::is_arithmetic<U>::value, T>::type
blas_dot(T* x, U* y, int size) {
    /*
        Use BLAS (if available) to perform dot product
        between two vectors x and y, each of length `size`.

        :param x: Pointer to the first element of the first vector
        :param y: Pointer to the first element of the second vector
        :param size: Length of the vectors
    */

    #ifdef HAVE_CBLAS
        int incx = 1;
        int incy = 1;

        if constexpr (std::is_same<T, float>::value) {
            if constexpr (std::is_same<U, float>::value) {
                return cblas_sdot(size, x, incx, y, incy);
            } else {
                // Avoid allocating and materializing a converted copy of y.
                return dot(x, y, size);
            }
        }
        else if constexpr (std::is_same<T, double>::value) {
            if constexpr (std::is_same<U, double>::value) {
                return cblas_ddot(size, x, incx, y, incy);
            } else {
                // Avoid allocating and materializing a converted copy of y.
                return dot(x, y, size);
            }
        }
    #else
        return dot(x, y, size);
    #endif
}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

// Define a function pointer for the axpy functions `axpy` and `blas_axpy`:
template <typename T, typename U>
using axpy_func_pt = typename std::enable_if<std::is_floating_point<T>::value && std::is_arithmetic<U>::value, void>::type (*)(T*, U*, T, int);

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

template <typename T, typename U>
typename std::enable_if<std::is_floating_point<T>::value && std::is_arithmetic<U>::value, void>::type
axpy(T* x, U* y, T alpha, int size) {
    /*
        Perform axpy operation on two vectors x and y, each of length `size`.
       axpy is a standard linear algebra operation that performs
       element-wise addition and multiplication:
       x := x + a*y.
    */

    #ifdef __wasm_simd128__
        if constexpr (std::is_same<T, float>::value && std::is_same<U, float>::value) {
            const v128_t scale = wasm_f32x4_splat(alpha);
            int i = 0;
            for (; i + 4 <= size; i += 4) {
                wasm_v128_store(
                    x + i,
                    wasm_f32x4_add(
                        wasm_v128_load(x + i),
                        wasm_f32x4_mul(wasm_v128_load(y + i), scale)
                    )
                );
            }
            for (; i < size; ++i) x[i] = std::fma(y[i], alpha, x[i]);
            return;
        } else if constexpr (std::is_same<T, double>::value && std::is_same<U, double>::value) {
            const v128_t scale = wasm_f64x2_splat(alpha);
            int i = 0;
            for (; i + 2 <= size; i += 2) {
                wasm_v128_store(
                    x + i,
                    wasm_f64x2_add(
                        wasm_v128_load(x + i),
                        wasm_f64x2_mul(wasm_v128_load(y + i), scale)
                    )
                );
            }
            for (; i < size; ++i) x[i] = std::fma(y[i], alpha, x[i]);
            return;
        }
    #endif

    #ifdef _OPENMP
        #ifndef _WIN32
            #pragma omp simd
        #endif
    #endif
    for (int i = 0; i < size; ++i) {
        x[i] = std::fma(static_cast<T>(y[i]), alpha, x[i]);
    }
}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

template <typename T, typename U>
typename std::enable_if<std::is_floating_point<T>::value && std::is_arithmetic<U>::value, void>::type
blas_axpy(T *y, U *x, T alpha, int size) {
    /*
        Use BLAS (if available) to perform axpy operation on two vectors x and y,
        each of length `size`.
       axpy is a standard linear algebra operation that performs
       element-wise addition and multiplication:
       x := x + a*y.
    */

    #ifdef HAVE_CBLAS
        int incx = 1;
        int incy = 1;

        if constexpr (std::is_same<T, float>::value) {
            if constexpr (std::is_same<U, float>::value) {
                cblas_saxpy(size, alpha, x, incx, y, incy);
            } else {
                // Avoid allocating and materializing a converted copy of x.
                axpy(y, x, alpha, size);
            }
        }
        else if constexpr (std::is_same<T, double>::value) {
            if constexpr (std::is_same<U, double>::value) {
                cblas_daxpy(size, alpha, x, incx, y, incy);
            } else {
                // Avoid allocating and materializing a converted copy of x.
                axpy(y, x, alpha, size);
            }
        }
    #else
        axpy(y, x, alpha, size);
    #endif
}

/* ------------------------------------------------------------------------ */
// Numerically stable softmax and sigmoid functions

template <typename T>
typename std::enable_if<std::is_floating_point<T>::value, void>::type
softmax(T* logits, T* output, int size) {
    /*
        Perform softmax operation on a vector of logits,
        and store the result in `output`. This function implements
        a numerically stable version of softmax to avoid overflow.
    */

    T s = 0., max_val = c_max(logits, size);

    for (int i = 0; i < size; ++i) {
        logits[i] = std::exp(logits[i] - max_val);
        s += logits[i];
    }

    for (int i = 0; i < size - 1; ++i) {
        output[i] = logits[i] / s;
    }
}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

template <typename T>
typename std::enable_if<std::is_floating_point<T>::value, T>::type
sigmoid(T x) {
    /*
        Perform sigmoid operation on a scalar x.
        This function implements a numerically stable version of sigmoid
        to avoid overflow.
    */

    if (x < 0) {
        T exp_x = std::exp(x);
        return exp_x / (1. + exp_x);
    }
    else {
        return 1. / (1. + std::exp(-x));
    }
}

/* ------------------------------------------------------------------------ */
// Helper functions for the E-step

template <typename T, typename U, typename I>
typename std::enable_if<std::is_floating_point<T>::value && std::is_arithmetic<U>::value && std::is_integral<I>::value, void>::type
update_q_factor_matrix(int c_size,
                        int n_active_models,
                        int* active_model_idx,
                        int* ld_left_bound,
                        I* ld_indptr,
                        U* ld_data,
                        T* eta,
                        T* q,
                        T dq_scale,
                        int threads) {
    /*
        Compute or update q factor, defined as the result of a dot product between the
        Linkage-disequilibrium matrix (LD) and the current value of eta (the posterior mean
        for the effect sizes). The definition of the q-factor excludes the diagonal elements.

        This function assumes that we have a matrix of eta values, where each column represents
        eta from a different model (this is relevant for grid-based models).

        The implementation below assumes that the eta and q matrices are column-major matrices.
    */

    I ld_start, ld_end, mat_idx;

    #ifdef _OPENMP
        #pragma omp parallel for private(ld_start, ld_end, mat_idx) schedule(static) num_threads(threads)
    #endif
    for (int j = 0; j < c_size; ++j) {
        ld_start = ld_indptr[j];
        ld_end = ld_indptr[j + 1];

        for (int m=0; m < n_active_models; ++m){
            mat_idx = active_model_idx[m]*c_size; // Assumes column-major matrices.
            q[mat_idx + j] += dq_scale*blas_dot(eta + (mat_idx + ld_left_bound[j]), ld_data + ld_start, ld_end - ld_start);
        }
    }
}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

template <typename T, typename U, typename I>
typename std::enable_if<std::is_floating_point<T>::value && std::is_arithmetic<U>::value && std::is_integral<I>::value, void>::type
update_q_factor(int c_size,
                 int* ld_left_bound,
                 I* ld_indptr,
                 U* ld_data,
                 T* eta,
                 T* q,
                 T dq_scale,
                 int threads) {
    /*
        Compute or update q factor, defined as the result of a dot product between the
        Linkage-disequilibrium matrix (LD) and the current value of eta (the posterior mean
        for the effect sizes). The definition of the q-factor excludes the diagonal elements.

        This function assumes that we have a vector of eta values. If you have a matrix of eta
        values, you should use the `update_q_factor_matrix` function instead.
    */

    I ld_start, ld_end;

    #ifdef _OPENMP
        #pragma omp parallel for private(ld_start, ld_end) schedule(static) num_threads(threads)
    #endif
    for (int j = 0; j < c_size; ++j) {

        ld_start = ld_indptr[j];
        ld_end = ld_indptr[j + 1];

        q[j] += dq_scale*blas_dot(eta + ld_left_bound[j], ld_data + ld_start, ld_end - ld_start);
    }
}

/* ------------------------------------------------------------------------ */
// E-step functions

template <typename T, typename U, typename I>
typename std::enable_if<std::is_floating_point<T>::value && std::is_arithmetic<U>::value && std::is_integral<I>::value, void>::type
e_step(int c_size,
        int* ld_left_bound,
        I* ld_indptr,
        U* ld_data,
        T* std_beta,
        T* var_gamma,
        T* var_mu,
        T* eta,
        T* q,
        T* eta_diff,
        T* u_logs,
        T* sqrt_half_var_tau,
        T* mu_mult,
        T dq_scale,
        int threads,
        bool low_memory) {

    /*
        Perform the E-Step of the coordinate-ascent variational inference (CAVI) algorithm for the
        simple spike-and-slab model.

        The function iterates over the variants in the dataset, and updates the posterior mean (var_mu) and
        posterior probability (var_gamma) according to the update rules in Zabad et al. (2023). The implementation
        assumes that the variational tau (inverse variance) have been updated prior to calling this function.

        In addition to updating the variational posterior parameters var_gamma and var_mu, the function also
        computes quantities used by the M-step and ELBO. These include the q-factor, eta_diff, per-variant zeta,
        component responsibility and zeta sums, and scalar entropy terms.
    */

    int start, end;
    I ld_start, ld_end;
    T u_j, mu_j, gamma_j, eta_diff_j;

    // Obtain the machine precision for the data type T:
    // TODO: Allow the user to set this value by passing an argument.
    T machine_precision = std::max(std::numeric_limits<T>::epsilon(), static_cast<T>(1e-8));

    #ifdef _OPENMP
        #pragma omp parallel for private(start, end, ld_start, ld_end, u_j, mu_j, gamma_j, eta_diff_j) schedule(static) num_threads(threads)
    #endif
    for (int j = 0; j < c_size; ++j) {

        ld_start = ld_indptr[j];
        ld_end = ld_indptr[j + 1];
        start = ld_left_bound[j];
        end = start + (ld_end - ld_start);

        /*
            Compute the posterior Gaussian mean for variant j
            This operation uses fused multiply-add to avoid numerical instability.
            The formula is:
            mu_j = mu_mult[j] * (std_beta[j] - q[j])
        */

        mu_j = std::fma(mu_mult[j], std_beta[j], -mu_mult[j] * q[j]);

        /* Compute the the posterior inclusion probability for variant j */
        u_j = sqrt_half_var_tau[j] * mu_j;
        gamma_j = sigmoid(std::fma(u_j, u_j, u_logs[j]));

        /* Update eta_diff for variant j */
        eta_diff_j = std::fma(gamma_j, mu_j, -eta[j]);

        if (std::abs(eta_diff_j) < machine_precision) {
            /* If the eta_diff is less than machine precision, set it to zero and continue */
            eta_diff[j] = 0.;
        }
        else{

            var_mu[j] = mu_j;
            var_gamma[j] = gamma_j;
            eta_diff[j] = eta_diff_j;

            /* Update the q-factors for variants that are in LD with variant j */
            blas_axpy(q + start, ld_data + ld_start, dq_scale*eta_diff_j, end - start);

            if (!low_memory) {
                /* If the matrix is symmetric, updating q in the previous step would also
                update the q-factor for the focal variant (j). So, we need to correct for
                this here. */
                q[j] -= eta_diff_j;
            }

            /* Update eta (posterior mean) for variant j */
            eta[j] += eta_diff_j;
        }
    }

    if (low_memory) {
        /* If the LD matrix used in the above operations is upper-triangular, then we would not
           have updated the q-factors of variants based on the new etas for variants that come after them
           in the dataset. So, we need to correct for that here: */
        update_q_factor(c_size, ld_left_bound, ld_indptr, ld_data, eta_diff, q, dq_scale, threads);
    }

}


/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

template <typename T, typename U, typename I>
typename std::enable_if<std::is_floating_point<T>::value && std::is_arithmetic<U>::value && std::is_integral<I>::value, void>::type
e_step_mixture(int c_size,
                int K,
                int* ld_left_bound,
                I* ld_indptr,
                U* ld_data,
                T* std_beta,
                T* var_gamma,
                T* var_mu,
                T* eta,
                T* q,
                T* eta_diff,
                T* log_null_pi,
                T* u_logs,
                T* var_tau,
                T* log_var_tau,
                T* sqrt_half_var_tau,
                T* mu_mult,
                double* zeta,
                double* gamma_sum,
                double* component_zeta,
                double* elbo_stats,
                T dq_scale,
                int threads,
                bool low_memory) {

    /*
        Perform the E-Step of the coordinate-ascent variational inference (CAVI) algorithm for the
        sparse scale-mixture of Gaussians model.

        The function iterates over the variants in the dataset, and updates the posterior mean (var_mu) and
        posterior probability (var_gamma) according to the update rules in Zabad et al. (2023). The implementation
        assumes that the variational tau (inverse variance) have been updated prior to calling this function.

        In addition to updating the variational posterior parameters var_gamma and var_mu, the function also
        computes certain quantities that are used in the M-step of the CAVI algorithm. These quantities include
        the q-factor for each variant (the dot product between the LD matrix and the posterior mean), and eta_diff,
        defined as the difference between the current value of eta and the updated value of eta.
    */

    // Obtain the machine precision for the data type T:
    T machine_precision = std::max(std::numeric_limits<T>::epsilon(), static_cast<T>(1e-8));

    /* Delineate the parallel region: */
    #ifdef _OPENMP
        #pragma omp parallel num_threads(threads)
    #endif
    {
        // Declare variables that are private to each thread:
        int start, end, mat_idx;
        I ld_start, ld_end;
        T mu_beta_j, mu_tau_j, eta_diff_j;
        T* u_j = new T[K + 1];

        // Accumulate component and ELBO statistics privately, then merge once
        // per thread to avoid synchronization in the per-variant loop.
        double* thread_gamma_sum = new double[K]();
        double* thread_component_zeta = new double[K]();
        // Entries are sum(gamma*log(gamma)), sum(null*log(null)),
        // sum(gamma*log(var_tau)), and sum(null), respectively.
        double thread_elbo_stats[4] = {0., 0., 0., 0.};

        #ifdef _OPENMP
            #pragma omp for schedule(static)
        #endif
        for (int j = 0; j < c_size; ++j) {

            ld_start = ld_indptr[j];
            ld_end = ld_indptr[j + 1];

            start = ld_left_bound[j];
            end = start + (ld_end - ld_start);

            /* Update the posterior mean for each variant j and each of the K mixture components */
            mu_beta_j = std_beta[j] - q[j];

            for (int k = 0; k < K; ++k) {
                mat_idx = j*K + k; // Assumes C-order matrices.
                var_mu[mat_idx] = mu_mult[mat_idx] * mu_beta_j;
                mu_tau_j = sqrt_half_var_tau[mat_idx] * var_mu[mat_idx];
                u_j[k] = std::fma(mu_tau_j, mu_tau_j, u_logs[mat_idx]);
            }

            /* Compute the posterior inclusion probability by applying softmax over the logits (u_j) */
            u_j[K] = log_null_pi[j];
            softmax(u_j, var_gamma + j*K, K + 1);

            /* Update eta_diff for variant j */
            eta_diff_j = -eta[j];
            T pip_j = 0.;
            double zeta_j = 0.;

            for (int k = 0; k < K; ++k) {
                mat_idx = j*K + k; // Assumes C-order matrices.
                eta_diff_j = std::fma(var_gamma[mat_idx], var_mu[mat_idx], eta_diff_j);

                // Cache posterior sufficient statistics while the component
                // parameters are already in the processor cache.
                T gamma_j = var_gamma[mat_idx];
                double clipped_gamma = clamp(
                    static_cast<double>(gamma_j), 1e-15, 1. - 1e-15
                );
                double component_second_moment = static_cast<double>(gamma_j) * (
                    static_cast<double>(var_mu[mat_idx]) * var_mu[mat_idx]
                    + 1. / static_cast<double>(var_tau[mat_idx])
                );

                pip_j += gamma_j;
                zeta_j += component_second_moment;
                thread_gamma_sum[k] += static_cast<double>(gamma_j);
                thread_component_zeta[k] += component_second_moment;
                thread_elbo_stats[0] += clipped_gamma * std::log(clipped_gamma);
                thread_elbo_stats[2] += (
                    clipped_gamma * static_cast<double>(log_var_tau[mat_idx])
                );
            }

            double null_gamma = clamp(
                1. - static_cast<double>(pip_j), 1e-15, 1. - 1e-15
            );
            zeta[j] = zeta_j;
            thread_elbo_stats[1] += null_gamma * std::log(null_gamma);
            thread_elbo_stats[3] += null_gamma;

            if (std::abs(eta_diff_j) < machine_precision) {
                /* Avoid propagating negligible changes through the LD matrix. */
                eta_diff[j] = 0.;
                continue;
            }

            eta_diff[j] = eta_diff_j;

            /* Update the q-factors for variants that are in LD with variant j */
            blas_axpy(q + start, ld_data + ld_start, dq_scale*eta_diff_j, end - start);

            if (!low_memory) {
                /* If the matrix is symmetric, updating q in the previous step would also
                update the q-factor for the focal variant (j). So, we need to correct for
                this here. */
                q[j] -= eta_diff_j;
            }

            eta[j] += eta_diff_j;
        }

        // Merge the thread-local sufficient statistics into the chromosome-
        // wide outputs initialized by the caller.
        #ifdef _OPENMP
            #pragma omp critical
        #endif
        {
            for (int k = 0; k < K; ++k) {
                gamma_sum[k] += thread_gamma_sum[k];
                component_zeta[k] += thread_component_zeta[k];
            }
            for (int i = 0; i < 4; ++i) {
                elbo_stats[i] += thread_elbo_stats[i];
            }
        }

        delete[] u_j;
        delete[] thread_gamma_sum;
        delete[] thread_component_zeta;

    }

    if (low_memory) {
        /*  If the LD matrix used in the above operations is upper-triangular, then we would not
            have updated the q-factors of variants based on the new etas for variants that come after them
            in the dataset. So, we need to correct for that here:
        */
        update_q_factor(c_size, ld_left_bound, ld_indptr, ld_data, eta_diff, q, dq_scale, threads);
    }

}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

template <typename T, typename U, typename I>
typename std::enable_if<std::is_floating_point<T>::value && std::is_arithmetic<U>::value && std::is_integral<I>::value, void>::type
e_step_grid(int c_size,
             int n_active_models,
             int* active_model_idx,
             int* ld_left_bound,
             I* ld_indptr,
             U* ld_data,
             T* std_beta,
             T* var_gamma,
             T* var_mu,
             T* eta,
             T* q,
             T* eta_diff,
             T* u_logs,
             T* half_var_tau,
             T* mu_mult,
             T dq_scale,
             int threads,
             bool low_memory) {
     /*
        Perform the E-Step of the coordinate-ascent variational inference (CAVI) algorithm for the
        a grid of spike-and-slab models. The grid is defined over the hyperparameters of the model, so that
        instead of one set of variational parameters for each variant, we have a vector of variational
        parameters consistent with the grid of models. In this implementation, the variational parameters form
        a matrix (rather than a vector) where the dimensions are (number of variants) x (number of models in the grid).

        The function iterates over the variants in the dataset, and updates the posterior mean (var_mu) and
        posterior probability (var_gamma) according to the update rules in Zabad et al. (2023). The implementation
        assumes that the variational tau (inverse variance) have been updated prior to calling this function.

        In addition to updating the variational posterior parameters var_gamma and var_mu, the function also
        computes certain quantities that are used in the M-step of the CAVI algorithm. These quantities include
        the q-factor for each variant (the dot product between the LD matrix and the posterior mean), and eta_diff,
        defined as the difference between the current value of eta and the updated value of eta.
    */

    int start, end, mat_idx, model_idx;
    I ld_start, ld_end;
    T u_j, eta_diff_j;

    // Obtain the machine precision for the data type T:
    T machine_precision = std::max(std::numeric_limits<T>::epsilon(), static_cast<T>(1e-8));

    #ifdef _OPENMP
        #pragma omp parallel for private(start, end, ld_start, ld_end, mat_idx, model_idx, u_j, eta_diff_j) schedule(static) num_threads(threads)
    #endif
    for (int j = 0; j < c_size; ++j) {

        ld_start = ld_indptr[j];
        ld_end = ld_indptr[j + 1];
        start = ld_left_bound[j];
        end = start + (ld_end - ld_start);

        /* Loop over the *active* models in the grid (i.e. models that still have not converged) */
        for (int m=0; m < n_active_models; ++m){

            model_idx = active_model_idx[m];
            mat_idx = model_idx*c_size + j; // Assumes column-major matrices.

            /* Update the posterior mean for variant j and model m */
            var_mu[mat_idx] = mu_mult[mat_idx] * (std_beta[j] - q[mat_idx]);

            /* Update the posterior inclusion probability for variant j and model m */
            u_j = u_logs[mat_idx] + half_var_tau[mat_idx] * var_mu[mat_idx] * var_mu[mat_idx];
            var_gamma[mat_idx] = sigmoid(u_j);

            /* Update eta_diff for variant j and model m */
            eta_diff_j = var_gamma[mat_idx] * var_mu[mat_idx] - eta[mat_idx];

            if (std::abs(eta_diff_j) < machine_precision) {
                /* Avoid propagating negligible changes through the LD matrix. */
                eta_diff[mat_idx] = 0.;
                continue;
            }

            eta_diff[mat_idx] = eta_diff_j;

            /* Update the q-factors for variants that are in LD with variant j */
            blas_axpy(q + (model_idx*c_size + start), ld_data + ld_start, dq_scale*eta_diff_j, end - start);

            if (!low_memory) {
                /* If the matrix is symmetric, updating q in the previous step would also
                update the q-factor for the focal variant (j). So, we need to correct for
                this here. */
                q[mat_idx] -= eta_diff_j;
            }

            /* Update eta (posterior mean) for variant j and model m */
            eta[mat_idx] += eta_diff_j;
        }
    }

    if (low_memory) {
        /* If the LD matrix used in the above operations is upper-triangular, then we would not
           have updated the q-factors of variants based on the new etas for variants that come after them
           in the dataset. So, we need to correct for that here:
        */
        update_q_factor_matrix(c_size, n_active_models, active_model_idx,
                               ld_left_bound, ld_indptr, ld_data, eta_diff,
                               q, dq_scale, threads);
    }

}


#endif // E_STEP_H
